package com.company;
import java.util.Arrays;
public class Main {

    public static void main(String[] args) {
	UnionFind unionFind =new UnionFind(10);
	unionFind.union(1,5);
	unionFind.union(4,1);
	unionFind.union(5,9);

        System.out.println(unionFind.connection(1,4));
        System.out.println(unionFind.connection(4,5));
        System.out.println(unionFind.connection(2,4));
        System.out.println(unionFind.connection(9,4));
        System.out.println(unionFind.connection(1,5));
        System.out.println(unionFind.connection(5,9));

    }
}
