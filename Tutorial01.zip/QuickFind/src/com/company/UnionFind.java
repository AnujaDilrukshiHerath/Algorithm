package com.company;

public class UnionFind {
    private int[] id;

    public UnionFind(int value) {
        this.id = new int[value];
        for(int i =0; i<value; i++){
            id[i] = i;

        }
    }
    public void union(int it1,int it2){
        for(int i =0; i<id.length;i++){
            if (id[i] ==it1-1) id[i] = id[it2-1];

        }
    }
    public boolean connection(int it1,int it2) {return id[it1-1]==id[it2-1];}
}
